
"""risk_calculations.py
Core risk functions:
- compute returns
- annualized volatility
- covariance matrix
- historical VaR (percentile)
- Monte Carlo VaR using multivariate normal simulation
"""
import numpy as np, pandas as pd

def compute_daily_returns(price_df):
    df = price_df.sort_values('date').copy()
    df['return'] = df['adj_close'].pct_change()
    return df.dropna(subset=['return'])

def annualized_volatility(returns, periods_per_year=252):
    return returns.std() * (periods_per_year ** 0.5)

def covariance_matrix(returns_df, periods_per_year=252):
    cov = returns_df.cov() * periods_per_year
    return cov

def historical_var(portfolio_returns, confidence=0.95):
    pct = 1 - confidence
    var = np.percentile(-portfolio_returns, 100*pct)
    return var

def monte_carlo_var(weights, mean_returns, cov_matrix, horizon_days=1, sims=10000, confidence=0.95):
    mean = np.array(mean_returns) * horizon_days
    cov = np.array(cov_matrix) * horizon_days
    sims_returns = np.random.multivariate_normal(mean, cov, size=sims)
    port_rets = sims_returns.dot(weights)
    pct = 1 - confidence
    var = np.percentile(-port_rets, 100*pct)
    return var, port_rets
