
"""ingest.py - sqlite3 version
Loads CSV price series from data/ into a SQLite database using sqlite3.
"""
import sqlite3, csv, os, sys
from pathlib import Path

def load_csvs_to_sqlite(data_dir, db_path):
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    for fp in sorted(os.listdir(data_dir)):
        if fp.endswith('.csv'):
            tablename = Path(fp).stem.replace('-','_').replace('.','_')
            rows = []
            cols = None
            with open(Path(data_dir)/fp, 'r') as f:
                reader = csv.reader(f)
                cols = next(reader)
                for r in reader:
                    rows.append(r)
            # create table
            col_defs = ','.join([f'"{c}" TEXT' for c in cols])
            cur.execute(f'DROP TABLE IF EXISTS "{tablename}"')
            cur.execute(f'CREATE TABLE "{tablename}" ({col_defs})')
            # insert rows with parameterized query
            placeholders = ','.join(['?']*len(cols))
            cur.executemany(f'INSERT INTO "{tablename}" VALUES ({placeholders})', rows)
            con.commit()
            print(f'Loaded {fp} -> table {tablename} (rows={len(rows)})')
    con.close()

if __name__=='__main__':
    data_dir = Path(__file__).resolve().parents[1] / 'data'
    db_path = Path(__file__).resolve().parents[1] / 'risk_data.db'
    if len(sys.argv)>1:
        db_path = Path(sys.argv[1].replace('sqlite:///', ''))
    load_csvs_to_sqlite(data_dir, db_path)
