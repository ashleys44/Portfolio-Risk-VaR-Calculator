
"""run_pipeline.py - sqlite3 pipeline
Creates outputs using CSVs in data/ and a local SQLite DB created by ingest.py
"""
from pathlib import Path
import pandas as pd, numpy as np, sqlite3, json, sys
from src import risk_calculations as rc
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parents[1]
DATA_DIR = BASE / 'data'
OUTPUT_DIR = BASE / 'outputs'
DB_PATH = BASE / 'risk_data.db'

# optional arg for db path
if len(sys.argv)>1:
    arg = sys.argv[1]
    if arg.startswith('sqlite:///'):
        DB_PATH = Path(arg.replace('sqlite:///', ''))
    else:
        DB_PATH = Path(arg)

OUTPUT_DIR.mkdir(exist_ok=True)

def load_from_csv_or_db(name):
    # try DB first
    if DB_PATH.exists():
        con = sqlite3.connect(DB_PATH)
        try:
            df = pd.read_sql_query(f"SELECT * FROM '{name}'", con, parse_dates=['date'])
            con.close()
            return df.sort_values('date')
        except Exception:
            con.close()
    # fallback to CSV
    return pd.read_csv(DATA_DIR / f'{name}.csv', parse_dates=['date']).sort_values('date')

tickers = ['AAPL','BTC-USD','EURUSD']
weights = np.array([0.5,0.3,0.2])

dfs = {t: load_from_csv_or_db(t) for t in tickers}
returns = {}
for t in tickers:
    r = rc.compute_daily_returns(dfs[t])
    returns[t] = r.set_index('date')['return']

# align indexes by intersection
common_index = returns[tickers[0]].index
for t in tickers[1:]:
    common_index = common_index.intersection(returns[t].index)
aligned = pd.DataFrame({t: returns[t].loc[common_index] for t in tickers}, index=common_index)

# metrics
ann_vol = {t: float(rc.annualized_volatility(aligned[t])) for t in tickers}
covm = rc.covariance_matrix(aligned)

port_rets = (aligned * weights).sum(axis=1)

hist_var_95 = float(rc.historical_var(port_rets, 0.95))
hist_var_99 = float(rc.historical_var(port_rets, 0.99))
mean_daily = aligned.mean()
cov_daily = aligned.cov()
mc_var_95, mc_sims = rc.monte_carlo_var(weights, mean_daily, cov_daily, horizon_days=1, sims=20000, confidence=0.95)

summary = {
    'tickers': tickers,
    'weights': weights.tolist(),
    'annualized_volatility': {k: round(v,6) for k,v in ann_vol.items()},
    'covariance_matrix_annualized': covm.round(6).to_dict(),
    'historical_var_95': round(hist_var_95,6),
    'historical_var_99': round(hist_var_99,6),
    'monte_carlo_var_95': round(mc_var_95,6)
}

(OUTPUT_DIR/'summary.json').write_text(json.dumps(summary, indent=2))

# plots
plt.figure(figsize=(8,4))
for t in tickers:
    plt.plot(dfs[t]['date'], dfs[t]['adj_close'], label=t)
plt.title('Price series (synthetic)')
plt.legend()
plt.tight_layout()
plt.savefig(OUTPUT_DIR/'prices.png')
plt.close()

cum = (1+port_rets).cumprod()-1
plt.figure(figsize=(8,4))
plt.plot(cum.index, cum.values)
plt.title('Portfolio cumulative returns')
plt.tight_layout()
plt.savefig(OUTPUT_DIR/'portfolio_cum_returns.png')
plt.close()

plt.figure(figsize=(8,4))
plt.hist(mc_sims, bins=100)
plt.axvline(-mc_var_95, linestyle='dashed', linewidth=2)
plt.title('Monte Carlo simulated portfolio returns (1-day)')
plt.tight_layout()
plt.savefig(OUTPUT_DIR/'mc_returns_hist.png')
plt.close()

print('Outputs saved to', OUTPUT_DIR)
